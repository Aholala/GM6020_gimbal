#include "stm32f10x.h"                  // Device header
#include "FreeRTOS.h"
#include "task.h"

#include "MPU6050.h"
#include "My_USART1.h"
#include "OLED.h"



//**��ʼ�����������**//
#define START_TASK_STACK 128
#define START_TASK_PRIO   1
TaskHandle_t START_TASK;
void start_task(void *pvParameters);

//**MPU6050�����������**//
#define MPU_Kalman_TASK_STACK 256
#define MPU_Kalman_TASK_PRIO   2
TaskHandle_t MPU_Kalman_TASK;
void MPU_Kalman_task(void *pvParameters);

//**OLED��ʾ�����������**//
#define OLED_TASK_STACK 256
#define OLED_TASK_PRIO   1
TaskHandle_t OLED_TASK;
void OLED_task(void *pvParameters);

//**Serial��ӡ�����������**//
#define Serial_TASK_STACK 128
#define Serial_TASK_PRIO   1
TaskHandle_t Serial_TASK;
void Serial_task(void *pvParameters);

/**
 * @brief       freertos_start
 * @note        ������ʼ���񣬴����������
 * @param      	void
 * @retval      void
 */
void freertos_start(void)
{
	
	xTaskCreate(
				(TaskFunction_t) 			start_task,
                (char *) 					"start_task", 
				(configSTACK_DEPTH_TYPE) 	START_TASK_STACK,
                (void *) 					NULL,
                (UBaseType_t) 				START_TASK_PRIO,
                (TaskHandle_t *)			&START_TASK
				);
	vTaskStartScheduler();
}

/**
 * @brief       ��ʼ����
 * @note        �ڿ�ʼ�����д�������ִ�е�����
 * @param      	void
 * @retval      void
 */
void start_task(void *pvParameters){
	taskENTER_CRITICAL();
	xTaskCreate(
				(TaskFunction_t) 			MPU_Kalman_task,
                (char *) 					"MPU_Kalman_task", /*lint !e971 Unqualified char types are allowed for strings and single characters only. */
				(configSTACK_DEPTH_TYPE) 	MPU_Kalman_TASK_STACK,
                (void *) 					NULL,
                (UBaseType_t) 				MPU_Kalman_TASK_PRIO,
                (TaskHandle_t *)			&MPU_Kalman_TASK
				);
	xTaskCreate(
				(TaskFunction_t) 			OLED_task,
                (char *) 					"LED2_task", /*lint !e971 Unqualified char types are allowed for strings and single characters only. */
				(configSTACK_DEPTH_TYPE) 	OLED_TASK_STACK,
                (void *) 					NULL,
                (UBaseType_t) 				OLED_TASK_PRIO,
                (TaskHandle_t *)			&OLED_TASK
				);
	xTaskCreate(
				(TaskFunction_t) 			Serial_task,
                (char *) 					"task3", /*lint !e971 Unqualified char types are allowed for strings and single characters only. */
				(configSTACK_DEPTH_TYPE) 	Serial_TASK_STACK,
                (void *) 					NULL,
                (UBaseType_t) 				Serial_TASK_PRIO,
                (TaskHandle_t *)			&Serial_TASK
				);
	Calibrate_Gyro(&MPU);
	MPU_Kalman_Filter_Init(&MPU_Kalman_Pitch,0.001,0.003,0.5);
	MPU_Kalman_Filter_Init(&MPU_Kalman_Roll,0.001,0.003,0.5);
	vTaskDelete(START_TASK);
	taskEXIT_CRITICAL();
}

/**
 * @brief       led1����
 * @note        led1��ת
 * @param      	void
 * @retval      void
 */
void MPU_Kalman_task(void *pvParameters)
{
	while(1)
	{
		MPU6050_Angle_Update(&Angle,&MPU,&MPU_Kalman_Pitch,&MPU_Kalman_Roll);
		vTaskDelay(10);
	}
}

void OLED_task(void *pvParameters)
{
	while(1)
	{
		OLED_Printf(0,0,OLED_6X8,"%+06.1f",Angle.pitch);
		OLED_Printf(0,10,OLED_6X8,"%+06.1f",Angle.roll);
		OLED_Printf(0,18,OLED_6X8,"%+06.1f",Angle.yaw);
		OLED_Update();  // ���Ӹ�����ʾ
		vTaskDelay(20);
	}
}

void Serial_task(void *pvParameters)
{
	while(1)
	{
		Serial_Printf("%.1f %.1f %.1f\r\n",Angle.pitch,Angle.roll,Angle.yaw);
		vTaskDelay(50);
	}
}