#ifndef __RTOS_CONTROL_H
#define __RTOS_CONTROL_H

void freertos_start(void);

#endif