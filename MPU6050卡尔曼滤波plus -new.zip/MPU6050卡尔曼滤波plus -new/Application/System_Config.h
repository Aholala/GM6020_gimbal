#ifndef __SYSTEM_CONFIG_H
#define __SYSTEM_CONFIG_H

void All_System_Config(void);
#endif