#include "stm32f10x.h"                  // Device header
#include "MPU6050.h"
#include "My_USART1.h"
#include "OLED.h"

void All_System_Config(void)
{
	
    Serial_Init(115200);
    Serial_Printf("System Start...\r\n");
    
    OLED_Init();
	OLED_Clear();
    OLED_Update();
    Serial_Printf("OLED Init OK\r\n");
    
    if(MPU6050_Init() == 0)
    {
        Serial_Printf("MPU6050 Init OK, ID=0x%02X\r\n", MPU6050_GetID());
    }
    else
    {
        Serial_Printf("MPU6050 Init FAILED!\r\n");
    }
}