#ifndef __MY_USART1_H
#define __MY_USART1_H
#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include <stdarg.h>
#define RX_BUFFER_SIZE 256
#define TX_BUFFER_SIZE 256

typedef struct{
	uint8_t RB_ID;
	uint8_t RB_X;
	uint8_t RB_Y;
	uint8_t RB_Active;
	uint32_t lastCmdTime;  // ����������ʱ��
}RB;

extern uint8_t Serial_RxData[RX_BUFFER_SIZE];		//���崮�ڽ��յ����ݱ���
extern uint16_t Serial_RxLength;		//���崮�ڽ��յı�־λ����
extern volatile uint8_t Serial_RxFlag;//���ձ�־λ

void Serial_Init(uint32_t Baud);

void Serial_SendByte(uint8_t Byte);

void Serial_SendArray(uint8_t *Array, uint16_t Length);

void Serial_SendString(char *String);

uint32_t Serial_Pow(uint32_t X, uint32_t Y);

void Serial_SendNumber(uint32_t Number, uint8_t Length);

void Serial_Printf(char *format, ...);

uint8_t Serial_GetRxFlag(void);

#endif

