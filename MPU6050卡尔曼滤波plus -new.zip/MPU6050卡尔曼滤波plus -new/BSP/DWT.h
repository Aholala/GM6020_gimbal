#ifndef __DWT_H
#define __DWT_H
#include "stm32f10x.h"

#include "stdint.h"

// DWT �Ĵ�������ַ
#define DWT_BASE          (0xE0001000UL)

// DWT �Ĵ����ṹ��
#define DWT               ((DWT_Type *) DWT_BASE)
typedef struct{
  volatile uint32_t CTRL;
  volatile uint32_t CYCCNT;
  volatile uint32_t CPICNT;
  volatile uint32_t EXCCNT;
  volatile uint32_t SLEEPCNT;
  volatile uint32_t LSUCNT;
  volatile uint32_t FOLDCNT;
  volatile uint32_t PCSR;
} DWT_Type;

// DWT CTRL �Ĵ���λ����
#define DWT_CTRL_CYCCNTENA_Pos         0U
#define DWT_CTRL_CYCCNTENA_Msk        (1UL << DWT_CTRL_CYCCNTENA_Pos)

void DWT_Init(void);
uint32_t DWT_GetTick(void);
void DWT_Delay(uint32_t ms);

#endif

