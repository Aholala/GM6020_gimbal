#include "DWT.h"
#include "stm32f10x.h"                  // Device header
#include "misc.h"
static uint32_t DWT_Count;

void DWT_Init(void)
{
    // ʹ��DWT������
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    DWT_Count = 0;
}

uint32_t DWT_GetTick(void)
{
    return DWT->CYCCNT / 72000; // ת��Ϊ����(72MHz��Ƶ)
}

void DWT_Delay(uint32_t ms)
{
    uint32_t startTick = DWT_GetTick();
    while((DWT_GetTick() - startTick) < ms);
}

