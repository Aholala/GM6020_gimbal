#ifndef __MY_DMA_H
#define __MY_DMA_H

void Usart1_DMA_Config(void);
#endif
