#include "stm32f10x.h"                  // Device header


void MPU_W_SCL(uint8_t BitValue)
{
	GPIO_WriteBit(GPIOB, GPIO_Pin_12, (BitAction)BitValue);
//	Delay_us(10);
}

void MPU_W_SDA(uint8_t BitValue)
{
	GPIO_WriteBit(GPIOB, GPIO_Pin_13, (BitAction)BitValue);
//	Delay_us(10);
}

uint8_t MPU_R_SDA(void)
{
	uint8_t BitValue;
	BitValue = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13);
//	Delay_us(10);
	return BitValue;
}

void MPU_I2C_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_SetBits(GPIOB, GPIO_Pin_12 | GPIO_Pin_13);
}

void MPU_I2C_Start(void)
{
	MPU_W_SDA(1);
	MPU_W_SCL(1);
	MPU_W_SDA(0);
	MPU_W_SCL(0);
}

void MPU_I2C_Stop(void)
{
	MPU_W_SDA(0);
	MPU_W_SCL(1);
	MPU_W_SDA(1);
}

void MPU_I2C_SendByte(uint8_t Byte)
{
	uint8_t i;
	for (i = 0; i < 8; i ++)
	{
		MPU_W_SDA(!!(Byte & (0x80 >> i)));
		MPU_W_SCL(1);
		MPU_W_SCL(0);
	}
}

uint8_t MPU_I2C_ReceiveByte(void)
{
	uint8_t i, Byte = 0x00;
	MPU_W_SDA(1);
	for (i = 0; i < 8; i ++)
	{
		MPU_W_SCL(1);
		if (MPU_R_SDA()){Byte |= (0x80 >> i);}
		MPU_W_SCL(0);
	}
	return Byte;
}

void MPU_I2C_SendAck(uint8_t AckBit)
{
	MPU_W_SDA(AckBit);
	MPU_W_SCL(1);
	MPU_W_SCL(0);
}

uint8_t MPU_I2C_ReceiveAck(void)
{
	uint8_t AckBit;
	MPU_W_SDA(1);
	MPU_W_SCL(1);
	AckBit = MPU_R_SDA();
	MPU_W_SCL(0);
	return AckBit;
}