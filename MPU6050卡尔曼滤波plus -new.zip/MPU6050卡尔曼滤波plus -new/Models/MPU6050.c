#include "stm32f10x.h"                  // Device header
#include <math.h>
#include "My_I2C.h"
#include "MPU6050.h"
#include "MPU6050_Reg.h"
#include "DWT.h"
#include "Delay.h"

#define MPU6050_ADDRESS		0xD0

void MPU6050_WriteReg(uint8_t RegAddress, uint8_t Data)
{
	MPU_I2C_Start();
	MPU_I2C_SendByte(MPU6050_ADDRESS);
	MPU_I2C_ReceiveAck();
	MPU_I2C_SendByte(RegAddress);
	MPU_I2C_ReceiveAck();
	MPU_I2C_SendByte(Data);
	MPU_I2C_ReceiveAck();
	MPU_I2C_Stop();
}

uint8_t MPU6050_ReadReg(uint8_t RegAddress)
{
	uint8_t Data;
	
	MPU_I2C_Start();
	MPU_I2C_SendByte(MPU6050_ADDRESS);
	MPU_I2C_ReceiveAck();
	MPU_I2C_SendByte(RegAddress);
	MPU_I2C_ReceiveAck();
	
	MPU_I2C_Start();
	MPU_I2C_SendByte(MPU6050_ADDRESS | 0x01);
	MPU_I2C_ReceiveAck();
	Data = MPU_I2C_ReceiveByte();
	MPU_I2C_SendAck(1);
	MPU_I2C_Stop();
	
	return Data;
}

void MPU6050_ReadRegs(uint8_t RegAddress, uint8_t *DataArray, uint8_t Count)
{
	MPU_I2C_Start();
	MPU_I2C_SendByte(MPU6050_ADDRESS);
	MPU_I2C_ReceiveAck();
	MPU_I2C_SendByte(RegAddress);
	MPU_I2C_ReceiveAck();
	
	MPU_I2C_Start();
	MPU_I2C_SendByte(MPU6050_ADDRESS | 0x01);
	MPU_I2C_ReceiveAck();
	for (uint8_t i = 0; i < Count; i ++)
	{
		DataArray[i] = MPU_I2C_ReceiveByte();
		if (i < Count - 1)
		{
			MPU_I2C_SendAck(0);
		}
		else
		{
			MPU_I2C_SendAck(1);
		}
	}
	MPU_I2C_Stop();
}

uint8_t MPU6050_Init(void)
{
	MPU_I2C_Init();
	MPU6050_WriteReg(MPU6050_PWR_MGMT_1, 0x80); // 复位设备
    Delay_ms(100);
	MPU6050_WriteReg(MPU6050_PWR_MGMT_1, 0x01);
	MPU6050_WriteReg(MPU6050_PWR_MGMT_2, 0x00);
	MPU6050_WriteReg(MPU6050_SMPLRT_DIV, 0x00);
	MPU6050_WriteReg(MPU6050_CONFIG, 0x03);
	MPU6050_WriteReg(MPU6050_GYRO_CONFIG, 0x00);
	MPU6050_WriteReg(MPU6050_ACCEL_CONFIG, 0x00);
	Delay_ms(100);
	return 0;
}

uint8_t MPU6050_GetID(void)
{
	return MPU6050_ReadReg(MPU6050_WHO_AM_I);
}


void MPU6050_GetData(MPU_t* MPU)
{
	uint8_t Data[14];
	MPU6050_ReadRegs(MPU6050_ACCEL_XOUT_H, Data, 14);
	
	MPU->AX = (Data[0] << 8) | Data[1];
	
	MPU->AY = (Data[2] << 8) | Data[3];
	
	MPU->AZ = (Data[4] << 8) | Data[5];
	
	MPU->GX = (Data[8] << 8) | Data[9];
	
	MPU->GY = (Data[10] << 8) | Data[11];
	
	MPU->GZ = (Data[12] << 8) | Data[13];
}


void MPU6050_Data_Update(MPU_t* MPU,float* gyro_x,float* gyro_y,float* gyro_z,float* ax_g,float* ay_g,float* az_g)
{
	MPU6050_GetData(MPU);
	*gyro_x = (float)MPU->GX / 131.0f;  // 俯仰角速度
    *gyro_y = (float)MPU->GY / 131.0f;  // 横滚角速度
    *gyro_z = (float)MPU->GZ / 131.0f;  // 偏航角速度
	*ax_g = (float)MPU->AX / 16384.0f;  // 俯仰角速度
    *ay_g = (float)MPU->AY / 16384.0f;  // 横滚角速度
    *az_g = (float)MPU->AZ / 16384.0f;  // 偏航角速度
	
}

